package pollingsystem;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;

/**
 *
 * @author Shannon Mtshatsheni
 */
public class ToVote extends javax.swing.JFrame {

    Connection conn;
    Statement st;
    ResultSet rs;
    PreparedStatement pst;
    public String pres;
    public String vpres;
    public String secretary;
    public String assistSecretary;
    public String treasurer;
    int presidentVote, secretaryVote, treasurerVote, assistantsecretaryVote, vPresidentVote;

    /**
     * Creates new form ToVotes
     */
    public ToVote() {

        try {
            initComponents();
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(200, 100, 400, 500);
            setTitle(" ToVote ");
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
            }

            conn = DriverManager.getConnection("jdbc:mysql://localhost/voting", "root", "");
            String sql = "SELECT * FROM `candidate`";
            st = conn.createStatement();
            rs = st.executeQuery(sql);

        } catch (SQLException ex) {
            Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
        pres();
        vPres();
        treasurer();
        secretary();
        assistantSecretary();
        

    }

    public void pres() {
        String sql = "select * from candidate where Position = 'President'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                presidentCB.addItem(rs.getString("Name"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void vPres() {
        String sql = "select * from candidate where Position = 'vicepresident'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                vicepresidentCB.addItem(rs.getString("Name"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void treasurer() {
        String sql = "select * from candidate where Position = 'treasurer'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                treasurerCB.addItem(rs.getString("Name"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void secretary() {
        String sql = "select * from candidate where Position = 'secretary'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                secretaryCB.addItem(rs.getString("Name"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void assistantSecretary() {
        String sql = "select * from candidate where Position = 'assistantsecretary'";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                assistantsecretaryCB.addItem(rs.getString("Name"));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void countVotePres() {
        try {
            String sql = "UPDATE `candidate` SET `VoteCount` = '2' WHERE `candidate`.`Name` = ' Nadine '";
            pst = conn.prepareStatement("UPDATE candidate SET VoteCount = 2 WHERE candidate.Name = ' Nadine '");
            int r = pst.executeUpdate();
            //JOptionPane.showMessageDialog(null, r + " updated " + presidentCB.getSelectedItem() );
            conn.close();
        } catch (Exception ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);

        }
        
     
    }

    public void countVoteVPresident() {
        try {
            
                String row = vicepresidentCB.getSelectedItem().toString();
                vPresidentVote = vPresidentVote+1;
               // String query = "UPDATE candidate SET VoteCount = '" + "'";
                
                
            
        } catch (Exception ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }

    public void countVoteForSecretary() {
        try {
            String sql = "select VoteCount from candidate where Name='" + secretaryCB.getSelectedItem() + "' AND position='Secretary'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                secretaryVote = Integer.parseInt(rs.getString("VoteCount")) + 1;
            }
        } catch (Exception ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void countForAssistantSecretary() {
        try {
            String sql = "select VoteCount from candidate where Name='" + assistantsecretaryCB.getSelectedItem() + "' AND position='assistantsecretary'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                assistantsecretaryVote = Integer.parseInt(rs.getString("VoteCount")) + 1;
            }
        } catch (Exception ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void countForTreasurer() {
        try {
            String sql = "select VoteCount from candidate where Name='" + treasurerCB.getSelectedItem() + "' AND position='Treasurer'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if (rs.next()) {
                treasurerVote = Integer.parseInt(rs.getString("VoteCount")) + 1;
            }
        } catch (Exception ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Back = new javax.swing.JButton();
        Vote = new javax.swing.JButton();
        presidentCB = new javax.swing.JComboBox();
        vicepresidentCB = new javax.swing.JComboBox();
        secretaryCB = new javax.swing.JComboBox();
        assistantsecretaryCB = new javax.swing.JComboBox();
        treasurerCB = new javax.swing.JComboBox();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pollingsystem/election.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("President");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Vice President");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Secretary");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Assistant Secretary");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Treasurer");

        Back.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Back.setText("Back");
        Back.setToolTipText("Go back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        Vote.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Vote.setText("Vote");
        Vote.setToolTipText("Complete vote");
        Vote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoteActionPerformed(evt);
            }
        });

        presidentCB.setToolTipText("President");
        presidentCB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                presidentCBActionPerformed(evt);
            }
        });

        vicepresidentCB.setToolTipText("Vice President");

        secretaryCB.setToolTipText("Secretary");

        assistantsecretaryCB.setToolTipText("Assistant Secretary");

        treasurerCB.setToolTipText("Treasurer");
        treasurerCB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                treasurerCBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Back, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(201, 201, 201)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Vote, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(secretaryCB, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(vicepresidentCB, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(presidentCB, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(assistantsecretaryCB, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(treasurerCB, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(46, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(presidentCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(vicepresidentCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(secretaryCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5)
                    .addComponent(assistantsecretaryCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addComponent(treasurerCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Back)
                    .addComponent(Vote))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        // TODO add your handling code here:

        String exit = JOptionPane.showInputDialog(null, "You are about to exit the voting screen!.Confirm Y/N? ");
        exit.toUpperCase();
        if (exit.equalsIgnoreCase("Y")) {
            StudentUser d = new StudentUser();
            d.setVisible(true);
            dispose();
        }


    }//GEN-LAST:event_BackActionPerformed


    private void VoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoteActionPerformed
        if (presidentCB.getSelectedIndex() == 0 || vicepresidentCB.getSelectedIndex() == 0 || secretaryCB.getSelectedIndex() == 0 || assistantsecretaryCB.getSelectedIndex() == 0 || treasurerCB.getSelectedIndex() == 0) {
           // JOptionPane.showMessageDialog(null, "YOU ARE DONE VOTING");

            int des = JOptionPane.showConfirmDialog(null, "Finish Voting?", "Confirmation", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (des == 0) {
                countVotePres();
               /* countVoteVPresident();
                countVoteForSecretary();
                countForAssistantSecretary();
                countForTreasurer();*/

                JOptionPane.showMessageDialog(null, "Voted Successfully!");
            }
        }
       
          
          FinishScreen f = new FinishScreen();
            f.setVisible(true);
            dispose();
         
    }//GEN-LAST:event_VoteActionPerformed

    private void presidentCBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_presidentCBActionPerformed


    }//GEN-LAST:event_presidentCBActionPerformed

    private void treasurerCBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_treasurerCBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_treasurerCBActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ToVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ToVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ToVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ToVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ToVote().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JButton Vote;
    private javax.swing.JComboBox assistantsecretaryCB;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JComboBox presidentCB;
    private javax.swing.JComboBox secretaryCB;
    private javax.swing.JComboBox treasurerCB;
    private javax.swing.JComboBox vicepresidentCB;
    // End of variables declaration//GEN-END:variables
}
