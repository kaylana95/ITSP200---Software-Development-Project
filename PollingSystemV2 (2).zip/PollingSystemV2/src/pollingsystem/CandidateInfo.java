/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingsystem;

import java.sql.*;
import java.util.logging.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Nadine
 */
public class CandidateInfo extends javax.swing.JFrame {

              Connection  conn;
              Statement st;
              ResultSet rs;
              PreparedStatement pst;
    public CandidateInfo() {
             
          try {
              initComponents();
              setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
              setBounds(200, 100, 500, 400);
              setTitle(" Candidate Information ");
              try {
                  Class.forName("com.mysql.jdbc.Driver");
              }
              catch (ClassNotFoundException ex) {
                  Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
              }
              
              conn = DriverManager.getConnection("jdbc:mysql://localhost/voting", "root", "");
              String sql="SELECT * FROM `candidate`";
              st = conn.createStatement();
              rs = st.executeQuery(sql);
          
              while(rs.next())
              {
                    String CandidateID = rs.getString(1);
                    String Name =  rs.getString(2);
                    String Surname = rs.getString(3);
                    String Age = rs.getString(4);
                    String Position = rs.getString(5);
                    String Email = rs.getString(6);
                 
                  Object [] information = {CandidateID, Name, Surname, Age, Position, Email};
                  DefaultTableModel model = (DefaultTableModel) CandidateInfoTable.getModel();
                  model.addRow(information);
              }
           
          } 
            catch (SQLException ex) {
                Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
          
    }

    
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        CandidateInfoTable = new javax.swing.JTable();
        CandidateInfomation = new javax.swing.JLabel();
        Back = new javax.swing.JButton();
        update = new javax.swing.JButton();
        Delete = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        CandidateInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "CandidateID", "Name", "Surname", "Age", "Position", "Email"
            }
        ));
        jScrollPane1.setViewportView(CandidateInfoTable);

        CandidateInfomation.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        CandidateInfomation.setText("Candidate Information");

        Back.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Back.setText("Back");
        Back.setToolTipText("Go back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        update.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        update.setText("Update");
        update.setToolTipText("Update table");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        Delete.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Delete.setText("Delete");
        Delete.setToolTipText("Delete row ");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(Back, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(58, 58, 58)
                        .addComponent(update)
                        .addGap(75, 75, 75)
                        .addComponent(Delete))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 532, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(CandidateInfomation)))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(CandidateInfomation, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Back)
                    .addComponent(update)
                    .addComponent(Delete))
                .addGap(21, 21, 21))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        
        Database data = new Database();
        data.setVisible(true);
         dispose();
    }//GEN-LAST:event_BackActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
      
        try {   
            try {
                Class.forName("com.mysql.jdbc.Driver");
            }
            catch (ClassNotFoundException ex) {
                Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
            conn = DriverManager.getConnection("jdbc:mysql://localhost/voting", "root", "");
            st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String sql= "UPDATE `candidate` SET `CandidateID`=?,`Name`=?,`Surname`=?,`Age`= ?,`Position`= ?, `Email`= ? ";
            pst = conn.prepareStatement(sql);
            int row = CandidateInfoTable.getSelectedRow();
            int select = CandidateInfoTable.convertRowIndexToModel(row);
            
           try 
            {
                while(rs.next())
                {
                    String CandidateID = rs.getString("CandidateID");
                    String Name = rs.getString("Name");
                    String Surname= rs.getString("Surname");
                    int Age = rs.getInt("Age");
                    String Position = rs.getString("Position");
                    String Email= rs.getString("Email");
                    rs.updateRow();
                    
                  Object [] information = {CandidateID, Name, Surname, Age, Position, Email};
                  DefaultTableModel model = (DefaultTableModel) CandidateInfoTable.getModel();
                }
                
                JOptionPane.showMessageDialog(null, "Updated Sucessfully");

            } catch (Exception e) 
            {
                 Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, e);

            }
           
        }
        catch (SQLException ex) {
            Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_updateActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        try {   
            
            try {
                Class.forName("com.mysql.jdbc.Driver");
            }
            catch (ClassNotFoundException ex) {
                Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
            }
             conn = DriverManager.getConnection("jdbc:mysql://localhost/voting", "root", "");
            st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            st = conn.createStatement();
            
            int row = CandidateInfoTable.getSelectedRow();
            String select = (CandidateInfoTable.getModel().getValueAt(row, 0)).toString();
            String sql= "DELETE FROM `candidate` WHERE `CandidateID` =  " + select;
            pst = conn.prepareStatement(sql);
            pst.executeUpdate();
            DefaultTableModel model = (DefaultTableModel) CandidateInfoTable.getModel();
            model.removeRow(row);
            JOptionPane.showMessageDialog(null, "Delete Sucessfully");

        }
        catch (SQLException ex) {
            Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_DeleteActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CandidateInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CandidateInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CandidateInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CandidateInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CandidateInfo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JTable CandidateInfoTable;
    private javax.swing.JLabel CandidateInfomation;
    private javax.swing.JButton Delete;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
