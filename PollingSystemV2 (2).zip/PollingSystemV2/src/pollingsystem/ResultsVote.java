/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pollingsystem;

import java.sql.*;
import java.util.Properties;
import java.util.logging.*;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.*;

/**
 *
 * @author Shannon Mtshatsheni
 */
public class ResultsVote extends javax.swing.JFrame {

    /**
     * Creates new form CountVote
     */
    
              Connection  conn;
              Statement st;
              ResultSet rs;
              PreparedStatement pst;
              String mail;
    
    public ResultsVote() {
        
        
        try {
              initComponents();
              setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
              setBounds(300, 100, 650, 600);
              setTitle(" Voting Results ");
              try {
                  Class.forName("com.mysql.jdbc.Driver");
              }
              catch (ClassNotFoundException ex) {
                  Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
              }
              
              conn = DriverManager.getConnection("jdbc:mysql://localhost/voting", "root", "");
              String sql="SELECT * FROM `candidate`";
              st = conn.createStatement();
              rs = st.executeQuery(sql);
          
              
           
          } 
            catch (SQLException ex) {
                Logger.getLogger(CandidateInfo.class.getName()).log(Level.SEVERE, null, ex);
            }

        showVotePres(); 
        showVoteVPres();
        showVoteSecretary();
        showVoteAssistantSecretary();
        showVoteTreasurer();
        
        
        

                
        
    }

   public void showVotePres() 
        {
         String sql = "select * from candidate where Position = 'president' order by VoteCount ";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                presidentname.setText(rs.getString("Name"));
                presidentnameV.setText(rs.getString("VoteCount"));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        }
   
   public void showVoteVPres() 
        {
         String sql = "select * from candidate where Position = 'vicepresident' order by VoteCount ";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                vicepresidentname.setText(rs.getString("Name"));
                VPresidentV.setText(rs.getString("VoteCount"));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        }
   
   public void showVoteSecretary() 
        {
         String sql = "select * from candidate where Position = 'secretary' order by VoteCount ";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                secretaryname.setText(rs.getString("Name"));
                SecretaryV.setText(rs.getString("VoteCount"));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        }
   
   public void showVoteAssistantSecretary() 
        {
         String sql = "select * from candidate where Position = 'assistantsecretary' order by VoteCount ";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                assistantsecretaryname.setText(rs.getString("Name"));
                AssistantSecretaryV.setText(rs.getString("VoteCount"));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        }
   
   public void showVoteTreasurer() 
        {
         String sql = "select * from candidate where Position = 'treasurer' order by VoteCount ";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                treasurername.setText(rs.getString("Name"));
                TreasurerV.setText(rs.getString("VoteCount"));
               
            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
   
        }
   
   

    

        

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        presidentname = new javax.swing.JTextField();
        vicepresidentname = new javax.swing.JTextField();
        secretaryname = new javax.swing.JTextField();
        assistantsecretaryname = new javax.swing.JTextField();
        treasurername = new javax.swing.JTextField();
        vicepresidentVotes = new javax.swing.JLabel();
        secretaryVotes = new javax.swing.JLabel();
        assistantsecretaryVotes = new javax.swing.JLabel();
        treasurerVotes = new javax.swing.JLabel();
        BackButton = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        presidentnameV = new javax.swing.JTextField();
        VPresidentV = new javax.swing.JTextField();
        SecretaryV = new javax.swing.JTextField();
        AssistantSecretaryV = new javax.swing.JTextField();
        TreasurerV = new javax.swing.JTextField();
        emailResults = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("RESULTS FOR THE SRC VOTING ");

        jLabel2.setText("Position ");

        jLabel3.setText("President");

        jLabel4.setText("Vice President");

        jLabel5.setText("Secretary");

        jLabel6.setText("Assistant Secretary");

        jLabel7.setText("Treasurer");

        presidentname.setEditable(false);
        presidentname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                presidentnameActionPerformed(evt);
            }
        });

        vicepresidentname.setEditable(false);
        vicepresidentname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vicepresidentnameActionPerformed(evt);
            }
        });

        secretaryname.setEditable(false);
        secretaryname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secretarynameActionPerformed(evt);
            }
        });

        assistantsecretaryname.setEditable(false);

        treasurername.setEditable(false);

        BackButton.setText("Back");
        BackButton.setToolTipText("Go back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });

        jLabel8.setText("Candidate Name");

        jLabel9.setText("Winning Votes");

        presidentnameV.setEditable(false);
        presidentnameV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                presidentnameVActionPerformed(evt);
            }
        });

        VPresidentV.setEditable(false);

        SecretaryV.setEditable(false);

        AssistantSecretaryV.setEditable(false);

        TreasurerV.setEditable(false);

        emailResults.setText("Email Results");
        emailResults.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailResultsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 123, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(presidentnameV, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel4))
                                .addGap(25, 25, 25)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(treasurername, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(presidentname, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                                            .addComponent(vicepresidentname)
                                            .addComponent(secretaryname)))
                                    .addComponent(assistantsecretaryname, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(assistantsecretaryVotes, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                                    .addComponent(secretaryVotes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(treasurerVotes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(44, 44, 44))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(AssistantSecretaryV, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                                    .addComponent(SecretaryV)
                                    .addComponent(TreasurerV))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(vicepresidentVotes, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(VPresidentV, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addComponent(BackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(77, 77, 77)
                        .addComponent(emailResults, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(106, 106, 106))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(presidentname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(presidentnameV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(VPresidentV, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4)
                        .addComponent(vicepresidentname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(vicepresidentVotes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(33, 33, 33)
                        .addComponent(secretaryVotes)
                        .addGap(34, 34, 34)
                        .addComponent(assistantsecretaryVotes)
                        .addGap(19, 19, 19))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(secretaryname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(SecretaryV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(assistantsecretaryname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(AssistantSecretaryV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(treasurername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TreasurerV, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 10, Short.MAX_VALUE)))
                .addComponent(treasurerVotes)
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(emailResults, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BackButton, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE))
                .addGap(18, 18, 18))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void vicepresidentnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vicepresidentnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_vicepresidentnameActionPerformed

    private void presidentnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_presidentnameActionPerformed
 
     
        
    }//GEN-LAST:event_presidentnameActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // TODO add your handling code here:
        Database data = new Database();
        data.setVisible(true);
        dispose();
    }//GEN-LAST:event_BackButtonActionPerformed

    private void presidentnameVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_presidentnameVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_presidentnameVActionPerformed

    private void secretarynameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secretarynameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_secretarynameActionPerformed

    private void emailResultsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailResultsActionPerformed
        
        
        String pres = presidentname.getText();
        String presVote = presidentnameV.getText();
        String vicePres = vicepresidentname.getText();
        String vicePresVote = VPresidentV.getText();
        String secr = secretaryname.getText();
        String secrV = SecretaryV.getText();
        String assistantSecr = assistantsecretaryname.getText(); 
        String assistantSecrV = AssistantSecretaryV.getText();
        String treasurer = treasurername.getText();
        String treasurerV = TreasurerV.getText();
        
        String sql = "select * from student";
        try {
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                mail=(rs.getString("Email Address").toString());
                final String username = "the.pokerfaceguy95@gmail.com";
        final String password = "miasanmia";
        
        Properties prop = new Properties();
        prop.put("mail.smtp.host", "smtp.gmail.com");
        prop.put("mail.smtp.port", "587");
        prop.put("mail.smtp.auth", "true");
        prop.put("mail.smtp.starttls.enable", "true"); //TLS
        prop.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        
        Session session = Session.getInstance(prop,
                new javax.mail.Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });
try {

            
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("the.pokerfaceguy95@gmail.com"));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(mail)
            );
            message.setSubject("Voting results");
            message.setText("President :  " +"\t\t\t" + pres +"\t" + presVote
                    + "\n" + "Vice President :" + "        " + "\t"  + vicePres + "\t" 
                    + vicePresVote + "\n" + "Secretary :  " + "\t\t\t" + secr + "\t"
                    + secrV + "\n" + "Assistant Secretary :  " + "\t" +
                    assistantSecr + "\t" + assistantSecrV + "\n" 
                    + "Treasurer :  " + "\t\t\t" + treasurer + "\t"  + treasurerV
                    );

            Transport.send(message);

         
            

        } catch (MessagingException e) {
            e.printStackTrace();
        }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ToVote.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
    }//GEN-LAST:event_emailResultsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ResultsVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ResultsVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ResultsVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ResultsVote.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ResultsVote().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AssistantSecretaryV;
    private javax.swing.JButton BackButton;
    private javax.swing.JTextField SecretaryV;
    private javax.swing.JTextField TreasurerV;
    private javax.swing.JTextField VPresidentV;
    private javax.swing.JLabel assistantsecretaryVotes;
    private javax.swing.JTextField assistantsecretaryname;
    private javax.swing.JButton emailResults;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField presidentname;
    private javax.swing.JTextField presidentnameV;
    private javax.swing.JLabel secretaryVotes;
    private javax.swing.JTextField secretaryname;
    private javax.swing.JLabel treasurerVotes;
    private javax.swing.JTextField treasurername;
    private javax.swing.JLabel vicepresidentVotes;
    private javax.swing.JTextField vicepresidentname;
    // End of variables declaration//GEN-END:variables
}
