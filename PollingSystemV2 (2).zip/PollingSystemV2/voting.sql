-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2019 at 10:37 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `voting`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('ndai', 'ndai'),
('nadine', 'nadine'),
('mpumi', 'mpumi');

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE IF NOT EXISTS `candidate` (
  `CandidateID` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Surname` varchar(100) NOT NULL,
  `Age` int(3) NOT NULL,
  `Position` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Vote_Count` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`CandidateID`, `Name`, `Surname`, `Age`, `Position`, `Email`, `Vote_Count`) VALUES
('001', 'Nadine', 'Jansen', 20, 'President', 'njansen990@gmail.com', 0),
('002', 'Chad', 'Johnston', 21, 'assistantsecretary', 'chad@gmail.com', 0),
('003', 'Lulu', 'Gumede', 22, 'vicepresident', 'lulu@gmail.com', 0),
('004', 'Mpumi', 'Mtshi', 23, 'treasurer', 'mpumi@gmail.com', 0),
('005', 'Shaun', 'jacobs', 24, 'secretary', 'shaun@gmail.com', 0),
('006', 'Peter', 'Paul', 29, 'president', 'peter@mail.com', 0),
('007', 'Frederick', 'Frank', 27, 'vicepresident', 'fred@gmail.com', 0),
('008', 'Silla', 'Jansen', 22, 'assistantsecretary', 'silla@gmail.com', 0),
('009', 'Henry', 'Peter', 26, 'secretary', 'henry@gmail.com', 0),
('010', 'Denver', 'Blues', 20, 'treasurer', 'den@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `StudentID` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Surname` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `Email Address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
